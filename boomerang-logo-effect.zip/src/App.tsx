/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { Play, RotateCcw, PlayCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isReversing, setIsReversing] = useState(false);
  const [showOverlay, setShowOverlay] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState('Ready');

  const LOOP_END_TIME = 8.0;
  const requestRef = useRef<number>(null);
  const lastFrameTimeRef = useRef<number>(0);

  const [videoSrc, setVideoSrc] = useState("Logo Animated Official.mp4");
  const [isDemo, setIsDemo] = useState(false);
  const [hasAttemptedLocal, setHasAttemptedLocal] = useState(false);

  const DEMO_VIDEO_URL = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";

  const rewind = (now: number) => {
    if (!videoRef.current) return;

    const delta = (now - lastFrameTimeRef.current) / 1000;
    lastFrameTimeRef.current = now;

    // Subtract time to simulate reverse
    const nextTime = Math.max(0, videoRef.current.currentTime - delta);
    videoRef.current.currentTime = nextTime;

    if (nextTime <= 0) {
      setIsReversing(false);
      setStatus('Playing ▶️');
      videoRef.current.play().catch(console.error);
    } else {
      requestRef.current = requestAnimationFrame(rewind);
    }
  };

  useEffect(() => {
    if (isReversing) {
      lastFrameTimeRef.current = performance.now();
      requestRef.current = requestAnimationFrame(rewind);
    } else {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isReversing]);

  const handlePlay = () => {
    if (!videoRef.current) return;

    setShowOverlay(false);
    setIsPlaying(true);
    setStatus('Playing ▶️');
    setError(null);
    setHasAttemptedLocal(true);
    
    videoRef.current.play().catch((err) => {
      console.error("Video play error:", err);
      handleVideoError();
    });
  };

  const handleVideoError = () => {
    console.error("Video element error");
    if (!isDemo) {
      setError("The video file 'Logo Animated Official.mp4' was not found. Switching to demo mode...");
      // Automatically switch to demo after a short delay
      setTimeout(() => {
        useDemoVideo();
      }, 2000);
    } else {
      setError("Even the demo video failed to load. Please check your internet connection.");
    }
    setShowOverlay(true);
    setStatus('Error ❌');
  };

  const useDemoVideo = () => {
    setVideoSrc(DEMO_VIDEO_URL);
    setIsDemo(true);
    setError(null);
    setShowOverlay(false);
    setIsPlaying(true);
    setStatus('Demo Mode ▶️');
    
    // Small delay to ensure src is updated before play
    setTimeout(() => {
      if (videoRef.current) {
        videoRef.current.load();
        videoRef.current.play().catch(console.error);
      }
    }, 100);
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;

    // Adjust loop time for demo video if needed
    const endTime = isDemo ? videoRef.current.duration * 0.8 : LOOP_END_TIME;

    if (!isReversing && videoRef.current.currentTime >= endTime) {
      setIsReversing(true);
      videoRef.current.pause();
      setStatus('Rewinding ⏪');
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-white flex flex-col items-center justify-center p-4 font-sans">
      <div className="w-full max-w-4xl">
        <div className="relative aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-white/10 group">
          <video
            ref={videoRef}
            className="w-full h-full object-contain"
            playsInline
            muted
            onTimeUpdate={handleTimeUpdate}
            onError={handleVideoError}
            src={videoSrc}
          />

          {/* Status Badge */}
          <AnimatePresence>
            {!showOverlay && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`absolute top-4 left-4 px-4 py-1.5 rounded-full text-sm font-medium backdrop-blur-md border border-white/10 z-20 ${
                  isReversing ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
                }`}
              >
                {status}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Overlay */}
          <AnimatePresence>
            {showOverlay && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center z-30 p-6 text-center"
              >
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.1 }}
                >
                  <h1 className="text-3xl md:text-4xl font-bold mb-4 tracking-tight">
                    Boomerang Effect
                  </h1>
                  <p className="text-gray-400 mb-8 max-w-md mx-auto">
                    Experience the smooth forward-reverse loop of the official animated logo.
                  </p>
                  
                  {error && (
                    <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-sm max-w-sm mx-auto">
                      <p className="font-bold mb-1">Notice</p>
                      <p className="opacity-80">{error}</p>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                    {!isDemo ? (
                      <button
                        onClick={handlePlay}
                        className="group relative flex items-center gap-3 bg-blue-600 hover:bg-blue-500 text-white px-8 py-4 rounded-full font-bold text-lg transition-all active:scale-95 shadow-lg shadow-blue-600/20"
                      >
                        <PlayCircle className="w-6 h-6 fill-current" />
                        <span>Start Boomerang</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => setShowOverlay(false)}
                        className="group relative flex items-center gap-3 bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-4 rounded-full font-bold text-lg transition-all active:scale-95 shadow-lg shadow-emerald-600/20"
                      >
                        <PlayCircle className="w-6 h-6 fill-current" />
                        <span>Resume Demo</span>
                      </button>
                    )}

                    {!isDemo && error && (
                      <button
                        onClick={useDemoVideo}
                        className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm font-medium underline underline-offset-4"
                      >
                        Skip to Demo
                      </button>
                    )}
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Subtle controls hint */}
          {!showOverlay && (
            <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
               <button 
                onClick={() => {
                  if (videoRef.current) {
                    videoRef.current.currentTime = 0;
                    setIsReversing(false);
                    videoRef.current.play();
                  }
                }}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-md border border-white/10"
                title="Restart"
               >
                 <RotateCcw className="w-5 h-5" />
               </button>
            </div>
          )}
        </div>

        {/* Info Section */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
          <div className="text-center">
            <div className="text-blue-400 font-mono text-sm mb-2 uppercase tracking-widest">Forward</div>
            <p className="text-gray-400 text-sm">Plays naturally until the 8-second mark.</p>
          </div>
          <div className="text-center">
            <div className="text-red-400 font-mono text-sm mb-2 uppercase tracking-widest">Reverse</div>
            <p className="text-gray-400 text-sm">Smoothly rewinds frame-by-frame to the start.</p>
          </div>
          <div className="text-center">
            <div className="text-emerald-400 font-mono text-sm mb-2 uppercase tracking-widest">Loop</div>
            <p className="text-gray-400 text-sm">Creates an infinite seamless motion effect.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
